// db/mongo.js
import mongoose from 'mongoose';

export const db = mongoose.connection;
